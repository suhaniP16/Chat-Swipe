import React, { useState } from "react";
import { useSwipeable } from "react-swipeable";
import "./chat.css";
const Chat = ({ chat, onAction }) => {
  const [isSwiped, setIsSwiped] = useState(false);

  const handlers = useSwipeable({
    onSwiping: (e) => {
      // Only trigger for horizontal swipes
      if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
        setIsSwiped(e.deltaX < 0); // Swipe left to show actions
      }
    },
    onSwiped: () => setIsSwiped(false),
    trackMouse: true,
    delta: 10, // Minimum swipe distance to trigger
    preventScrollOnSwipe: true, // Prevent scroll conflict
  });

  const handleAction = (action) => {
    onAction(chat.id, action);
    setIsSwiped(false);
  };

  return (
    <div {...handlers} className="chat-container">
      <div className={`chat-content ${isSwiped ? "swiped" : ""}`}>
        <div className="chat-message">{chat.message}</div>
        {isSwiped && (
          <div className="chat-actions">
            <button
              onClick={() => handleAction("archive")}
              aria-label="Archive"
            >
              {/* 📦 */}
              Archive
            </button>
            <button onClick={() => handleAction("move")} aria-label="Move">
              {/* 📁 */}
              Move
            </button>
            <button onClick={() => handleAction("rename")} aria-label="Rename">
              {/* ✏️ */}
              Rename
            </button>
            <button
              onClick={() => handleAction("delete")}
              aria-label="Delete"
              className="delete-btn"
            >
              {/* 🗑️ */}
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;

import React, { useState } from "react";
import "./App.css";
import Chat from "./Chat/Chat";
const App = () => {
  const [chats, setChats] = useState([
    { id: 1, message: "Hello, how can I help you?" },
    { id: 2, message: "What are your business hours?" },
    { id: 3, message: "Can I get a refund?" },
  ]);

  const handleAction = (id, action) => {
    switch (action) {
      case "archive":
        setChats(
          chats.map((chat) =>
            chat.id === id ? { ...chat, archived: true } : chat
          )
        );
        break;
      case "move":
        const folder = prompt("Enter folder name:");
        if (folder) {
          setChats(
            chats.map((chat) => (chat.id === id ? { ...chat, folder } : chat))
          );
        }
        break;
      case "rename":
        const newMessage = prompt(
          "New message:",
          chats.find((c) => c.id === id).message
        );
        if (newMessage) {
          setChats(
            chats.map((chat) =>
              chat.id === id ? { ...chat, message: newMessage } : chat
            )
          );
        }
        break;
      case "delete":
        if (window.confirm("Delete this chat permanently?")) {
          setChats(chats.filter((chat) => chat.id !== id));
        }
        break;
      default:
        break;
    }
  };

  return (
    <div className="App">
      <h1 className="delete-btn">Chat Bot</h1>
      <div className="chat-list">
        {chats.map((chat) => (
          <Chat key={chat.id} chat={chat} onAction={handleAction} />
        ))}
      </div>
    </div>
  );
};

export default App;
